function gatherIntelligentSignals() {
    const forms = Array.from(document.querySelectorAll('form')).map(f => {
        return { id: f.id, action: f.action, method: f.method, className: f.className };
    });
    const inputs = Array.from(document.querySelectorAll('input')).map(i => {
        return { type: i.type, name: i.name, id: i.id };
    });
    const scripts = Array.from(document.querySelectorAll('script')).map(s => {
        return s.src || s.innerText.substring(0, 100);
    });
    return {
        forms: forms,
        inputs: inputs,
        protocol: window.location.protocol,
        url: window.location.href,
        scripts: scripts
    };
}

document.getElementById('scanBtn').addEventListener('click', async () => {
    const statusDiv = document.getElementById('status');
    statusDiv.innerText = "Scanning active tab...";
    statusDiv.style.color = "#ffd700";
    
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        
        if (!tab || tab.url.startsWith('chrome://')) {
            statusDiv.innerText = "Cannot scan this page type.";
            return;
        }

        // Execute directly to avoid needing a page refresh or content script injection state errors
        const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: gatherIntelligentSignals,
        });

        if (!results || !results[0] || !results[0].result) {
            statusDiv.innerText = "Failed to extract DOM data.";
            return;
        }

        const payload = results[0].result;
        statusDiv.innerText = "Signals gathered. Calling Backend...";

        // Send to background to do the cross-origin POST
        chrome.runtime.sendMessage({ action: "runAnalysis", payload: payload }, (bgResponse) => {
             if (chrome.runtime.lastError) {
                 statusDiv.innerText = "Background Relaying Error: " + chrome.runtime.lastError.message;
                 statusDiv.style.color = "#ff003c";
                 return;
             }
             if (bgResponse && bgResponse.success) {
                 statusDiv.innerText = `Analysis Complete! Risk: ${bgResponse.risk_score}%`;
                 statusDiv.style.color = "#39ff14";
             } else {
                 statusDiv.innerText = "Backend Connection Refused. Is Port 8000 running?";
                 statusDiv.style.color = "#ff003c";
             }
        });

    } catch (err) {
        statusDiv.innerText = "Execution Error: " + err.message;
        statusDiv.style.color = "#ff003c";
    }
});
