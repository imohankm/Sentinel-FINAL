import React, { useState, useEffect, useRef } from 'react';
import { Terminal, Shield, ShieldAlert, Cpu, Network, Zap, User, Search, Database, Lock, AlertTriangle, CheckCircle } from 'lucide-react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import './index.css';

// Simulation sequences
const AI_AGENTS = [
  { id: 'agent-recon', name: 'Recon-OSINT', color: '#00f3ff', icon: Search },
  { id: 'agent-strategy', name: 'Logic-Core', color: '#b800ff', icon: Cpu },
  { id: 'agent-social', name: 'Human-Sim', color: '#ff003c', icon: User },
  { id: 'agent-exploit', name: 'Breach-Forge', color: '#39ff14', icon: Zap },
];

const ATTACK_LOGS = [
  { agent: 'agent-recon', text: 'Initializing passive DNS reconnaissance on target: http://localhost:8080' },
  { agent: 'agent-recon', text: 'Found 1 exposed web server. Mapping open ports...' },
  { agent: 'agent-strategy', text: 'Analyzing open ports. HTTPS, MySQL exposed on external interfaces.' },
  { agent: 'agent-strategy', text: 'Warning: 3306 (MySQL) should not be public. Checking for known CVEs.' },
  { agent: 'agent-recon', text: 'Scraping employee LinkedIn data. Found 12 IT admins.' },
  { agent: 'agent-social', text: 'Drafting spear-phishing simulation targeting "John Doe (IT Admin)". Theme: "Urgent VPN Update".' },
  { agent: 'agent-social', text: 'Simulated User clicked link. Evaluating endpoint security response.' },
  { agent: 'agent-exploit', text: 'No EDR detected on simulated endpoint. Payload delivered successfully.' },
  { agent: 'agent-strategy', text: 'Lateral movement path calculated. Pivoting from user workstation to internal subnet.' },
  { agent: 'agent-exploit', text: 'Attempting default credentials on internal administrative portal.' },
  { agent: 'agent-exploit', text: 'SUCCESS: Access gained to admin interface. Deploying simulated web shell.' },
  { agent: 'agent-strategy', text: 'Simulation complete. Aggregating vulnerability data for final report.' }
];

// Data for charts
const vulnerabilityData = [
  { name: 'Critical', count: 2, color: '#ff003c' }, // Neon Red
  { name: 'High', count: 4, color: '#ff8c00' }, // Orange
  { name: 'Medium', count: 7, color: '#ffd700' }, // Yellow
  { name: 'Low', count: 15, color: '#00f3ff' }, // Neon Blue
];

const attackVectorData = [
  { name: 'Phishing', successRate: 85 },
  { name: 'Weak Creds', successRate: 60 },
  { name: 'Open Ports', successRate: 90 },
  { name: 'Missing EDR', successRate: 100 },
];

export default function App() {
  const [isExtensionEnabled, setIsExtensionEnabled] = useState(false);
  const [simulationState, setSimulationState] = useState('idle'); // idle, running, complete
  const [logs, setLogs] = useState([]);
  const logsEndRef = useRef(null);

  // Auto-scroll logs
  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const handleEnableExtension = () => {
    setIsExtensionEnabled(true);
  };

  const startSimulation = () => {
    if (!isExtensionEnabled) return;
    setSimulationState('running');
    setLogs([]);
    
    let currentLog = 0;
    const logInterval = setInterval(() => {
      if (currentLog < ATTACK_LOGS.length) {
        setLogs(prev => [...prev, ATTACK_LOGS[currentLog]]);
        currentLog++;
      } else {
        clearInterval(logInterval);
        setTimeout(() => setSimulationState('complete'), 1000);
      }
    }, 1000); // 1.0s per step for a slightly faster demo
  };

  return (
    <div className="scanline" style={{ minHeight: '100vh', padding: '2rem' }}>
      {/* Header */}
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem', borderBottom: '1px solid var(--border-color)', paddingBottom: '1rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <ShieldAlert size={32} color="var(--neon-blue)" />
          <h1 className="neon-text-blue" style={{ fontSize: '1.8rem', margin: 0 }}>SentinelAI Cyber Simulator</h1>
        </div>
        <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
          <span style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>SERVER STATUS:</span>
          {isExtensionEnabled ? (
             <span style={{ color: 'var(--neon-green)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
               <Network size={16} /> CONNECTED TO LOCAL TARGET
             </span>
          ) : (
            <span style={{ color: 'var(--neon-red)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
               <Database size={16} /> ISOLATED
             </span>
          )}
        </div>
      </header>

      <main style={{ display: 'grid', gridTemplateColumns: 'minmax(300px, 1fr) 2fr', gap: '2rem' }}>
        
        {/* Left Column - Controls */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div className="glass-panel" style={{ padding: '1.5rem' }}>
            <h2 style={{ fontSize: '1.2rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Lock size={20} /> Target Configuration
            </h2>
            <div style={{ marginBottom: '1.5rem' }}>
              <label style={{ display: 'block', marginBottom: '0.5rem', color: 'var(--text-secondary)' }}>Target Environment</label>
              <input 
                type="text" 
                value="http://localhost:8080 (Fake Server)" 
                disabled 
                style={{ width: '100%', padding: '0.5rem', background: 'rgba(0,0,0,0.5)', border: '1px solid var(--border-color)', color: 'var(--text-primary)', borderRadius: '4px' }} 
              />
            </div>
            
            <div style={{ marginBottom: '1rem' }}>
              {!isExtensionEnabled ? (
                 <button onClick={handleEnableExtension} className="btn" style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '0.5rem' }}>
                   Enable AI Extension on Target
                 </button>
              ) : (
                 <button disabled className="btn btn-success" style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '0.5rem' }}>
                   <CheckCircle size={16} /> Extension Active
                 </button>
              )}
            </div>
          </div>

          <div className="glass-panel" style={{ padding: '1.5rem' }}>
             <h2 style={{ fontSize: '1.2rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Cpu size={20} /> Multi-Agent Swarm
             </h2>
             <div style={{ display: 'flex', flexDirection: 'column', gap: '0.8rem' }}>
               {AI_AGENTS.map(agent => {
                  const AgentIcon = agent.icon;
                  return (
                    <div key={agent.id} style={{ display: 'flex', alignItems: 'center', gap: '1rem', padding: '0.5rem', background: 'rgba(255,255,255,0.02)', borderRadius: '4px', borderLeft: `3px solid ${agent.color}` }}>
                       <AgentIcon size={18} color={agent.color} />
                       <span style={{ fontSize: '0.9rem' }}>{agent.name}</span>
                       {(simulationState === 'running' || simulationState === 'complete') && (
                         <span style={{ marginLeft: 'auto', fontSize: '0.8rem', color: 'var(--neon-green)' }}>ACTIVE</span>
                       )}
                    </div>
                  );
               })}
             </div>
             
             <div style={{ marginTop: '2rem' }}>
               <button 
                 onClick={startSimulation} 
                 disabled={!isExtensionEnabled || simulationState !== 'idle'} 
                 className={`btn ${!isExtensionEnabled ? '' : 'btn-danger'}`}
                 style={{ width: '100%', padding: '1rem', fontSize: '1.1rem' }}
               >
                 {simulationState === 'idle' ? 'LAUNCH SIMULATION' : simulationState === 'running' ? 'SIMULATION IN PROGRESS...' : 'SIMULATION COMPLETE'}
               </button>
             </div>
          </div>
        </div>

        {/* Right Column - Logs & Report */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', height: 'calc(100vh - 150px)' }}>
          {simulationState !== 'complete' && (
            <div className="glass-panel" style={{ flex: 1, padding: '0', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
              <div style={{ padding: '1rem', borderBottom: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', gap: '0.5rem', background: 'rgba(0,0,0,0.3)' }}>
                <Terminal size={18} /> <span>Live Agent Terminal</span>
              </div>
              <div style={{ padding: '1.5rem', flex: 1, overflowY: 'auto', fontFamily: 'monospace', fontSize: '0.9rem', lineHeight: '1.5' }}>
                {logs.length === 0 && simulationState === 'idle' && (
                  <div style={{ color: 'var(--text-secondary)', textAlign: 'center', marginTop: '4rem' }}>
                    System Idle. Deploy extension and launch simulation.
                  </div>
                )}
                {logs.map((log, index) => {
                  const agent = AI_AGENTS.find(a => a.id === log.agent);
                  return (
                    <div key={index} style={{ marginBottom: '0.8rem', display: 'flex', gap: '1rem' }}>
                      <span style={{ color: agent.color, whiteSpace: 'nowrap' }}>[{agent.name}]</span>
                      <span style={{ color: 'var(--text-primary)' }}>{log.text}</span>
                    </div>
                  );
                })}
                {simulationState === 'running' && (
                  <div style={{ display: 'flex', gap: '1rem', opacity: 0.7 }}>
                    <span style={{ color: 'var(--text-secondary)' }}>[System]</span>
                    <span className="cursor-blink">_</span>
                  </div>
                )}
                <div ref={logsEndRef} />
              </div>
            </div>
          )}

          {simulationState === 'complete' && (
            <div className="glass-panel" style={{ flex: 1, padding: '2rem', overflowY: 'auto' }}>
               <h2 className="neon-text-red" style={{ fontSize: '1.8rem', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                 <AlertTriangle size={28} /> Simulation Report
               </h2>
               
               <p style={{ color: 'var(--text-secondary)', marginBottom: '2rem' }}>
                 The automated swarm has completed mapping the target environment. Multiple high-severity vulnerabilities were identified through chained attack paths.
               </p>

               <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem', marginBottom: '2rem' }}>
                  {/* Vulnerability Severity Pie Chart */}
                  <div style={{ background: 'rgba(0,0,0,0.3)', padding: '1rem', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
                    <h3 style={{ textAlign: 'center', marginBottom: '1rem', fontSize: '1.1rem' }}>Severity Distribution</h3>
                    <div style={{ width: '100%', height: 250 }}>
                      <ResponsiveContainer>
                        <PieChart>
                          <Pie
                            data={vulnerabilityData}
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="count"
                            stroke="none"
                          >
                            {vulnerabilityData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip contentStyle={{ backgroundColor: 'rgba(5, 5, 10, 0.9)', borderColor: 'var(--border-color)', color: '#fff' }} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Attack Vector Bar Chart */}
                  <div style={{ background: 'rgba(0,0,0,0.3)', padding: '1rem', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
                    <h3 style={{ textAlign: 'center', marginBottom: '1rem', fontSize: '1.1rem' }}>Attack Vector Success Rate (%)</h3>
                    <div style={{ width: '100%', height: 250 }}>
                      <ResponsiveContainer>
                        <BarChart data={attackVectorData} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#333" horizontal={false} />
                          <XAxis type="number" domain={[0, 100]} stroke="#8b8b99" />
                          <YAxis dataKey="name" type="category" width={100} stroke="#8b8b99" tick={{fill: '#e0e0ff', fontSize: 12}} />
                          <Tooltip cursor={{fill: 'rgba(255,255,255,0.05)'}} contentStyle={{ backgroundColor: 'rgba(5, 5, 10, 0.9)', borderColor: 'var(--border-color)', color: '#fff' }} />
                          <Bar dataKey="successRate" fill="var(--neon-purple)" radius={[0, 4, 4, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
               </div>

               <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
                 <div>
                   <h3 style={{ borderBottom: '1px solid #444', paddingBottom: '0.5rem', marginBottom: '1rem' }}>Key Discoveries</h3>
                   <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                     <li style={{ background: 'rgba(255,0,60,0.1)', padding: '1rem', borderLeft: '4px solid var(--neon-red)', borderRadius: '4px' }}>
                       <strong style={{ color: 'var(--neon-red)' }}>[CRITICAL] External Database Exposure</strong>
                       <p style={{ fontSize: '0.9rem', marginTop: '0.5rem', color: 'var(--text-secondary)' }}>MySQL port 3306 is open to the internet allowing potential brute-force or CVE exploits.</p>
                     </li>
                     <li style={{ background: 'rgba(255,0,60,0.1)', padding: '1rem', borderLeft: '4px solid var(--neon-red)', borderRadius: '4px' }}>
                       <strong style={{ color: 'var(--neon-red)' }}>[CRITICAL] Weak Internal Credentials</strong>
                       <p style={{ fontSize: '0.9rem', marginTop: '0.5rem', color: 'var(--text-secondary)' }}>Administrative portal uses default 'admin/admin' credentials.</p>
                     </li>
                   </ul>
                 </div>

                 <div>
                   <h3 style={{ borderBottom: '1px solid #444', paddingBottom: '0.5rem', marginBottom: '1rem' }}>Attack Path Synopsis</h3>
                   <div style={{ background: 'rgba(0,0,0,0.3)', padding: '1.5rem', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
                     <ol style={{ paddingLeft: '1.5rem', color: 'var(--text-primary)', lineHeight: '1.8' }}>
                       <li><strong>Recon:</strong> Identified employee emails via OSINT.</li>
                       <li><strong>Phishing:</strong> Delivered benign payload via simulated spear-phishing.</li>
                       <li><strong>Initial Access:</strong> Simulated user clicked link. Gained access to workstation.</li>
                       <li><strong>Lateral Movement:</strong> Scanned internal subnet, found Fake Server active.</li>
                       <li><strong>Exploitation:</strong> Logged into server admin using default creds, deployed web shell.</li>
                     </ol>
                   </div>
                   
                   <button onClick={() => setSimulationState('idle')} className="btn" style={{ marginTop: '2rem', width: '100%' }}>
                     RESET SIMULATION
                   </button>
                 </div>
               </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
