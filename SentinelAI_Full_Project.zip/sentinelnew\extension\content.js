// Reads the DOM to gather intelligent signals

function gatherIntelligentSignals() {
    // 1. Gather Forms
    const forms = Array.from(document.querySelectorAll('form')).map(f => {
        return {
            id: f.id,
            action: f.action,
            method: f.method,
            className: f.className
        };
    });

    // 2. Gather Inputs
    const inputs = Array.from(document.querySelectorAll('input')).map(i => {
        return {
            type: i.type,
            name: i.name,
            id: i.id
        };
    });

    // 3. Gather Scripts (looking for exposed APIs)
    const scripts = Array.from(document.querySelectorAll('script')).map(s => {
        return s.src || s.innerText.substring(0, 50); // limit payload size
    });

    return {
        forms: forms,
        inputs: inputs,
        protocol: window.location.protocol,
        url: window.location.href,
        scripts: scripts
    };
}

// Listen for popup trigger
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "scanDOM") {
        const payload = gatherIntelligentSignals();
        sendResponse({ payload: payload });
    }
});
